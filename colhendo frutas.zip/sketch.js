let trees = []; // Lista para armazenar as árvores
let fruits = []; // Lista para armazenar as frutas
let boy; // O menino com a cesta
let fruitSize = 20; // Tamanho da fruta
let fruitFallSpeed = 2; // Velocidade com que as frutas caem
let boySpeed = 5; // Velocidade de movimento do menino
let score = 0; // Pontuação
let gameOver = false; // Estado de "game over"
let groundHeight = 50; // Altura do chão

function setup() {
  createCanvas(600, 400);
  
  // Posições das 3 árvores espalhadas
  trees.push(createTree(width / 6, 150)); // Primeira árvore
  trees.push(createTree(width / 2, 150)); // Segunda árvore
  trees.push(createTree(5 * width / 6, 150)); // Terceira árvore

  // Inicializando o menino
  boy = new Boy(width / 2, height - groundHeight - 40);
}

function draw() {
  background(220);

  if (gameOver) {
    displayGameOver();
    return;
  }

  // Desenha o chão
  fill(100, 150, 100); // Cor do chão
  rect(0, height - groundHeight, width, groundHeight); // Chão

  // Desenha as árvores
  for (let tree of trees) {
    drawTree(tree.x, tree.y);
  }
  
  updateFruits();
  
  // Desenha o menino com a cesta
  boy.display();
  
  // Movimenta o menino com as teclas
  if (keyIsDown(LEFT_ARROW)) {
    boy.move(-boySpeed);
  }
  if (keyIsDown(RIGHT_ARROW)) {
    boy.move(boySpeed);
  }
  
  // Checa se o menino pegou alguma fruta
  for (let i = fruits.length - 1; i >= 0; i--) {
    let fruit = fruits[i];
    if (boy.isTouching(fruit)) {
      fruits.splice(i, 1); // Remove a fruta que foi pega
      score += 10; // Adiciona pontos à pontuação
    } else if (fruit.y > height - groundHeight) {
      // Se a fruta não for pega e cair no chão
      gameOver = true; // Fim de jogo
    }
  }
  
  // Adiciona frutas aleatórias a cada 100 quadros
  if (frameCount % 100 === 0) {
    addFruit();
  }

  // Exibe a pontuação na tela
  displayScore();
}

// Função para criar uma árvore
function createTree(x, y) {
  return {x, y};
}

// Função para desenhar a árvore
function drawTree(x, y) {
  fill(139, 69, 19); // Cor do tronco
  rect(x - 20, y, 40, 100); // Tronco

  fill(34, 139, 34); // Cor da copa
  ellipse(x, y - 40, 150, 150); // Copa da árvore
}

// Função para adicionar frutas aleatoriamente
function addFruit() {
  let randomTree = random(trees); // Escolhe uma árvore aleatória
  let fruitX = randomTree.x + random(-75, 75); // A fruta pode cair em qualquer lugar ao redor da árvore
  let fruitY = randomTree.y - 50; // Início da queda da fruta
  fruits.push(new Fruit(fruitX, fruitY));
}

// Função para atualizar as frutas
function updateFruits() {
  for (let i = fruits.length - 1; i >= 0; i--) {
    fruits[i].fall();
    fruits[i].display();
  }
}

// Função para exibir a pontuação na tela
function displayScore() {
  fill(0);
  textSize(24);
  textAlign(RIGHT);
  text("Pontos: " + score, width - 20, 30);
}

// Função para exibir a tela de "Game Over"
function displayGameOver() {
  fill(0);
  textSize(32);
  textAlign(CENTER, CENTER);
  text("Game Over", width / 2, height / 2 - 40);
  textSize(24);
  text("Pontos finais: " + score, width / 2, height / 2);
  textSize(18);
  text("Pressione 'R' para reiniciar", width / 2, height / 2 + 40);
  
  // Reinicia o jogo quando a tecla "R" for pressionada
  if (keyIsDown(82)) { // 'R' para reiniciar
    restartGame();
  }
}

// Função para reiniciar o jogo
function restartGame() {
  score = 0;
  gameOver = false;
  fruits = [];
  boy.x = width / 2;
  boy.y = height - groundHeight - 40;
}

// Classe para a fruta
class Fruit {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 20; // Tamanho da fruta
  }

  fall() {
    this.y += fruitFallSpeed; // Faz a fruta cair
  }

  display() {
    fill(255, 0, 0); // Cor da fruta (vermelha)
    ellipse(this.x, this.y, this.size, this.size);
  }
}

// Classe para o menino com cesta
class Boy {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 30;
    this.cestaWidth = 50;
    this.cestaHeight = 10;
  }

  move(speed) {
    this.x += speed;
    this.x = constrain(this.x, 0, width); // Limita o movimento do menino para não sair da tela
  }

  display() {
    fill(0, 0, 255); // Cor do menino (azul)
    ellipse(this.x, this.y - 10, this.size, this.size); // Corpo do menino

    // Cesta
    fill(139, 69, 19); // Cor da cesta (marrom)
    rect(this.x - this.cestaWidth / 2, this.y + 10, this.cestaWidth, this.cestaHeight); // Cesta
  }

  isTouching(fruit) {
    let d = dist(this.x, this.y, fruit.x, fruit.y);
    return d < this.size / 2 + fruit.size / 2; // Verifica se o menino tocou na fruta
  }
}